package com.dicoding.mycustomlint

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MAINActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}