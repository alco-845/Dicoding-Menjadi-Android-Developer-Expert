package com.dicoding.mysimplecleanarchitecture.domain

data class MessageEntity(
    var welcomeMessage: String
)